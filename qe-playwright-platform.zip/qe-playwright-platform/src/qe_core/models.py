from __future__ import annotations

from dataclasses import dataclass
from pathlib import Path


@dataclass(frozen=True)
class ApplicationDefinition:
    key: str
    directory: str
    display_name: str
    base_path: str
    default_owner: str


@dataclass(frozen=True)
class StreamDefinition:
    key: str
    description: str


@dataclass(frozen=True)
class TestCaseDefinition:
    case_id: str
    name: str
    app: str
    module: str
    streams: list[str]
    owner: str
    severity: str
    description: str
    tags: list[str]
    test_file: str
    source_file: Path | None = None
