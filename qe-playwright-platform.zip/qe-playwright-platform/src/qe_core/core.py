from __future__ import annotations

import os
from pathlib import Path
from typing import Any

import pytest
import yaml
from dotenv import load_dotenv

from .models import ApplicationDefinition, StreamDefinition, TestCaseDefinition


class QeCore:
    def __init__(self) -> None:
        load_dotenv()
        self.applications: tuple[ApplicationDefinition, ...] = (
            ApplicationDefinition(
                key="google-home",
                directory="google_home",
                display_name="Google Home",
                base_path="",
                default_owner="qe-google",
            ),
            ApplicationDefinition(
                key="google-search",
                directory="google_search",
                display_name="Google Search",
                base_path="",
                default_owner="qe-google",
            ),
        )
        self.streams: tuple[StreamDefinition, ...] = (
            StreamDefinition(key="smoke", description="Fast validation of critical coverage."),
            StreamDefinition(key="regression", description="Broader functional regression coverage."),
            StreamDefinition(key="release", description="Release gate coverage."),
        )

    @property
    def base_url(self) -> str:
        return os.getenv("BASE_URL", "")

    @property
    def database_url(self) -> str:
        return os.getenv("DATABASE_URL", "")

    @property
    def environment(self) -> str:
        return os.getenv("QE_ENVIRONMENT", "local")

    @property
    def triggered_by(self) -> str:
        return os.getenv("QE_TRIGGERED_BY", "qe-team")

    @property
    def browsers_csv(self) -> str:
        return os.getenv("QE_BROWSERS", "chrome,msedge")

    @property
    def headless(self) -> bool:
        return os.getenv("QE_HEADLESS", "true").lower() in {"1", "true", "yes"}

    def repo_root(self) -> Path:
        return Path(__file__).resolve().parents[2]

    def get_application(self, key: str) -> ApplicationDefinition:
        for application in self.applications:
            if application.key == key:
                return application
        raise KeyError(f"Unknown application '{key}'.")

    def get_stream(self, key: str) -> StreamDefinition:
        for stream in self.streams:
            if stream.key == key:
                return stream
        raise KeyError(f"Unknown stream '{key}'.")

    def app_directory(self, app_key: str) -> Path:
        return self.repo_root() / "src" / "apps" / self.get_application(app_key).directory

    def testcase_directory(self, app_key: str) -> Path:
        return self.app_directory(app_key) / "testcases"

    def load_test_case_from_file(self, file_path: Path) -> TestCaseDefinition:
        raw = yaml.safe_load(file_path.read_text(encoding="utf-8"))
        test_case = TestCaseDefinition(
            case_id=raw["caseId"],
            name=raw["name"],
            app=raw["app"],
            module=raw["module"],
            streams=list(raw["streams"]),
            owner=raw["owner"],
            severity=raw["severity"],
            description=raw["description"],
            tags=list(raw.get("tags", [])),
            test_file=raw["testFile"],
            source_file=file_path,
        )
        self.get_application(test_case.app)
        for stream in test_case.streams:
            self.get_stream(stream)
        return test_case

    def load_test_case(self, app_key: str, case_id: str) -> TestCaseDefinition:
        return self.load_test_case_from_file(self.testcase_directory(app_key) / f"{case_id}.yml")

    def discover_test_cases(self) -> list[TestCaseDefinition]:
        cases: list[TestCaseDefinition] = []
        for application in self.applications:
            directory = self.testcase_directory(application.key)
            if not directory.exists():
                continue
            for file_path in sorted(directory.glob("*.yml")):
                cases.append(self.load_test_case_from_file(file_path))
        return sorted(cases, key=lambda item: item.case_id)

    def resolve_test_file(self, test_case: TestCaseDefinition) -> Path:
        return self.app_directory(test_case.app) / test_case.test_file

    def browser_channels(self, value: str | None = None) -> list[str]:
        selected = value or self.browsers_csv
        channels = [item.strip() for item in selected.split(",") if item.strip()]
        if not channels:
            raise pytest.UsageError("At least one browser channel is required.")
        unsupported = [item for item in channels if item not in {"chrome", "msedge"}]
        if unsupported:
            raise pytest.UsageError(f"Unsupported browser channels: {', '.join(unsupported)}")
        return channels

    def app_url(self, app_key: str) -> str:
        application = self.get_application(app_key)
        if application.base_path:
            return f"{self.base_url.rstrip('/')}{application.base_path}"
        return self.base_url

    def marker_name(self, prefix: str, value: str) -> str:
        return f"{prefix}_{self.slug(value)}"

    def slug(self, value: str) -> str:
        return "".join(character if character.isalnum() else "_" for character in value).strip("_").lower()

    def build_case_marks(self, test_case: TestCaseDefinition) -> list[pytest.MarkDecorator]:
        marks: list[pytest.MarkDecorator] = [
            pytest.mark.qe_meta(
                case_id=test_case.case_id,
                app=test_case.app,
                streams=test_case.streams,
                owner=test_case.owner,
                module=test_case.module,
                severity=test_case.severity,
                test_file=test_case.test_file,
            ),
            getattr(pytest.mark, self.marker_name("app", test_case.app)),
        ]
        marks.extend(getattr(pytest.mark, self.marker_name("stream", stream)) for stream in test_case.streams)
        return marks

    def screenshot_path(self, test_name: str, browser_channel: str) -> Path:
        artifact_dir = self.repo_root() / "artifacts" / "screenshots"
        artifact_dir.mkdir(parents=True, exist_ok=True)
        return artifact_dir / f"{self.slug(test_name)}__{browser_channel}.png"

    def reporting_enabled(self) -> bool:
        return bool(self.database_url)

    def run_status(self, exitstatus: int) -> str:
        return "passed" if exitstatus == 0 else "failed"


core = QeCore()
