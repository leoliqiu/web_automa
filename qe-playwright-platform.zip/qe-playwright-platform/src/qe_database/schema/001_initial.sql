CREATE TABLE IF NOT EXISTS applications (
  app_key TEXT PRIMARY KEY,
  display_name TEXT NOT NULL,
  base_path TEXT NOT NULL,
  default_owner TEXT NOT NULL,
  created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE TABLE IF NOT EXISTS streams (
  stream_key TEXT PRIMARY KEY,
  description TEXT NOT NULL,
  created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE TABLE IF NOT EXISTS test_cases (
  case_key TEXT PRIMARY KEY,
  app_key TEXT NOT NULL REFERENCES applications(app_key),
  module_name TEXT NOT NULL,
  case_name TEXT NOT NULL,
  owner_name TEXT NOT NULL,
  severity TEXT NOT NULL,
  description TEXT NOT NULL,
  tags TEXT[] NOT NULL DEFAULT '{}',
  test_file TEXT NOT NULL,
  source_file TEXT NOT NULL,
  is_active BOOLEAN NOT NULL DEFAULT TRUE,
  created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE TABLE IF NOT EXISTS test_case_streams (
  case_key TEXT NOT NULL REFERENCES test_cases(case_key) ON DELETE CASCADE,
  stream_key TEXT NOT NULL REFERENCES streams(stream_key),
  created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  PRIMARY KEY (case_key, stream_key)
);

CREATE TABLE IF NOT EXISTS test_runs (
  run_id BIGSERIAL PRIMARY KEY,
  environment TEXT NOT NULL,
  triggered_by TEXT NOT NULL,
  base_url TEXT NOT NULL,
  app_filter TEXT,
  stream_filter TEXT,
  case_filter TEXT,
  status TEXT NOT NULL,
  started_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  finished_at TIMESTAMPTZ
);

CREATE TABLE IF NOT EXISTS test_results (
  result_id BIGSERIAL PRIMARY KEY,
  run_id BIGINT NOT NULL REFERENCES test_runs(run_id) ON DELETE CASCADE,
  case_key TEXT REFERENCES test_cases(case_key),
  app_key TEXT REFERENCES applications(app_key),
  node_id TEXT NOT NULL,
  title TEXT NOT NULL,
  file_path TEXT NOT NULL,
  status TEXT NOT NULL,
  duration_ms INTEGER NOT NULL,
  error_message TEXT,
  browser_name TEXT NOT NULL,
  recorded_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE INDEX IF NOT EXISTS idx_test_runs_started_at ON test_runs(started_at DESC);
CREATE INDEX IF NOT EXISTS idx_test_results_run_id ON test_results(run_id);
CREATE INDEX IF NOT EXISTS idx_test_results_case_key ON test_results(case_key);
