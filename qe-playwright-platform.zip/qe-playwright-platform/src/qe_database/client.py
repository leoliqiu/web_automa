from __future__ import annotations

from psycopg import connect
from psycopg.connection import Connection

from qe_core import core


def get_connection() -> Connection:
    if not core.database_url:
        raise RuntimeError("DATABASE_URL is not set.")
    return connect(core.database_url)
