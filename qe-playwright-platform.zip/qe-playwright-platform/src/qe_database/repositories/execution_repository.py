from __future__ import annotations

from dataclasses import dataclass

from qe_core import core
from qe_database.client import get_connection


@dataclass(frozen=True)
class RunContext:
    environment: str
    triggered_by: str
    base_url: str
    app_filter: str | None
    stream_filter: str | None
    case_filter: str | None


@dataclass(frozen=True)
class TestResultRecord:
    run_id: int
    case_id: str | None
    app: str | None
    node_id: str
    title: str
    file_path: str
    status: str
    duration_ms: int
    error_message: str | None
    browser_name: str


class ExecutionRepository:
    def sync_catalog(self) -> None:
        test_cases = core.discover_test_cases()
        with get_connection() as connection:
            with connection.cursor() as cursor:
                for application in core.applications:
                    cursor.execute(
                        """
                        INSERT INTO applications (app_key, display_name, base_path, default_owner)
                        VALUES (%s, %s, %s, %s)
                        ON CONFLICT (app_key) DO UPDATE
                        SET display_name = EXCLUDED.display_name,
                            base_path = EXCLUDED.base_path,
                            default_owner = EXCLUDED.default_owner,
                            updated_at = NOW();
                        """,
                        (
                            application.key,
                            application.display_name,
                            application.base_path,
                            application.default_owner,
                        ),
                    )

                for stream in core.streams:
                    cursor.execute(
                        """
                        INSERT INTO streams (stream_key, description)
                        VALUES (%s, %s)
                        ON CONFLICT (stream_key) DO UPDATE
                        SET description = EXCLUDED.description,
                            updated_at = NOW();
                        """,
                        (stream.key, stream.description),
                    )

                for test_case in test_cases:
                    cursor.execute(
                        """
                        INSERT INTO test_cases (
                          case_key,
                          app_key,
                          module_name,
                          case_name,
                          owner_name,
                          severity,
                          description,
                          tags,
                          test_file,
                          source_file
                        )
                        VALUES (%s, %s, %s, %s, %s, %s, %s, %s, %s, %s)
                        ON CONFLICT (case_key) DO UPDATE
                        SET app_key = EXCLUDED.app_key,
                            module_name = EXCLUDED.module_name,
                            case_name = EXCLUDED.case_name,
                            owner_name = EXCLUDED.owner_name,
                            severity = EXCLUDED.severity,
                            description = EXCLUDED.description,
                            tags = EXCLUDED.tags,
                            test_file = EXCLUDED.test_file,
                            source_file = EXCLUDED.source_file,
                            is_active = TRUE,
                            updated_at = NOW();
                        """,
                        (
                            test_case.case_id,
                            test_case.app,
                            test_case.module,
                            test_case.name,
                            test_case.owner,
                            test_case.severity,
                            test_case.description,
                            test_case.tags,
                            test_case.test_file,
                            str(test_case.source_file) if test_case.source_file else "",
                        ),
                    )

                    cursor.execute("DELETE FROM test_case_streams WHERE case_key = %s", (test_case.case_id,))
                    for stream in test_case.streams:
                        cursor.execute(
                            """
                            INSERT INTO test_case_streams (case_key, stream_key)
                            VALUES (%s, %s)
                            ON CONFLICT (case_key, stream_key) DO NOTHING;
                            """,
                            (test_case.case_id, stream),
                        )

    def create_run(self, context: RunContext) -> int:
        with get_connection() as connection:
            with connection.cursor() as cursor:
                cursor.execute(
                    """
                    INSERT INTO test_runs (
                      environment,
                      triggered_by,
                      base_url,
                      app_filter,
                      stream_filter,
                      case_filter,
                      status
                    )
                    VALUES (%s, %s, %s, %s, %s, %s, 'running')
                    RETURNING run_id;
                    """,
                    (
                        context.environment,
                        context.triggered_by,
                        context.base_url,
                        context.app_filter,
                        context.stream_filter,
                        context.case_filter,
                    ),
                )
                row = cursor.fetchone()
                if row is None:
                    raise RuntimeError("Failed to create run record.")
                return int(row[0])

    def complete_run(self, run_id: int, status: str) -> None:
        with get_connection() as connection:
            with connection.cursor() as cursor:
                cursor.execute(
                    """
                    UPDATE test_runs
                    SET status = %s,
                        finished_at = NOW()
                    WHERE run_id = %s;
                    """,
                    (status, run_id),
                )

    def record_result(self, result: TestResultRecord) -> None:
        with get_connection() as connection:
            with connection.cursor() as cursor:
                cursor.execute(
                    """
                    INSERT INTO test_results (
                      run_id,
                      case_key,
                      app_key,
                      node_id,
                      title,
                      file_path,
                      status,
                      duration_ms,
                      error_message,
                      browser_name
                    )
                    VALUES (%s, %s, %s, %s, %s, %s, %s, %s, %s, %s);
                    """,
                    (
                        result.run_id,
                        result.case_id,
                        result.app,
                        result.node_id,
                        result.title,
                        result.file_path,
                        result.status,
                        result.duration_ms,
                        result.error_message,
                        result.browser_name,
                    ),
                )
