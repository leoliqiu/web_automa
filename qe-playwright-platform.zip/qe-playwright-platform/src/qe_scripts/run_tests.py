from __future__ import annotations

import argparse
import subprocess
import sys
from pathlib import Path

from qe_core import core


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(description="Run filtered pytest suites for the QE platform.")
    parser.add_argument("--app")
    parser.add_argument("--stream")
    parser.add_argument("--case")
    parser.add_argument("--browser", default=None)
    parser.add_argument("pytest_args", nargs="*")
    return parser


def select_files(app: str | None, stream: str | None, case_id: str | None) -> list[Path]:
    selected = []
    for test_case in core.discover_test_cases():
        if app and test_case.app != app:
            continue
        if stream and stream not in test_case.streams:
            continue
        if case_id and test_case.case_id != case_id:
            continue
        selected.append(core.resolve_test_file(test_case))

    if not app and not stream and not case_id:
        return [Path("src/apps")]

    unique = sorted({path for path in selected})
    if not unique:
        raise SystemExit("No test files matched the supplied filters.")
    return unique


def main() -> None:
    parser = build_parser()
    args, pytest_args = parser.parse_known_args()
    test_files = select_files(args.app, args.stream, args.case)

    command = [sys.executable, "-m", "pytest"]
    command.extend(str(path) for path in test_files)

    if args.app:
        command.extend(["--app", args.app])
    if args.stream:
        command.extend(["--stream", args.stream])
    if args.case:
        command.extend(["--case", args.case])
    if args.browser:
        command.extend(["--browser", args.browser])

    command.extend(pytest_args)
    raise SystemExit(subprocess.call(command))


if __name__ == "__main__":
    main()
