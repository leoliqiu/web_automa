"""CLI scripts for QE platform."""
