from __future__ import annotations

from qe_core import core


def main() -> None:
    cases = core.discover_test_cases()
    if not cases:
        print("No test cases found.")
        return

    for case in cases:
        print(
            f"{case.case_id:<14} {case.app:<18} {case.module:<12} "
            f"{','.join(case.streams):<20} {case.owner:<12} {case.name}"
        )


if __name__ == "__main__":
    main()
