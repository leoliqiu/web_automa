from __future__ import annotations

from pathlib import Path

from qe_database.client import get_connection


def main() -> None:
    schema_dir = Path(__file__).resolve().parents[1] / "qe_database" / "schema"
    files = sorted(schema_dir.glob("*.sql"))

    with get_connection() as connection:
        with connection.cursor() as cursor:
            cursor.execute(
                """
                CREATE TABLE IF NOT EXISTS schema_migrations (
                  version TEXT PRIMARY KEY,
                  applied_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
                );
                """
            )

            for file_path in files:
                cursor.execute("SELECT 1 FROM schema_migrations WHERE version = %s", (file_path.name,))
                if cursor.fetchone():
                    continue

                cursor.execute(file_path.read_text(encoding="utf-8"))
                cursor.execute("INSERT INTO schema_migrations (version) VALUES (%s)", (file_path.name,))
                print(f"Applied migration {file_path.name}")


if __name__ == "__main__":
    main()
