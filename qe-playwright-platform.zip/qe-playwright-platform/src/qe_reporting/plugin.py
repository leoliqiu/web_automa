from __future__ import annotations

from typing import Any

import pytest

from qe_core import core
from qe_database.repositories.execution_repository import (
    ExecutionRepository,
    RunContext,
    TestResultRecord,
)


def _repository() -> ExecutionRepository:
    return ExecutionRepository()


def initialize_reporting(config: pytest.Config) -> None:
    config._qe_reporting_enabled = core.reporting_enabled()  # type: ignore[attr-defined]
    config._qe_run_id = None  # type: ignore[attr-defined]
    config._qe_recorded_nodeids = set()  # type: ignore[attr-defined]

    if not config._qe_reporting_enabled:  # type: ignore[attr-defined]
        return

    repository = _repository()
    repository.sync_catalog()
    config._qe_run_id = repository.create_run(  # type: ignore[attr-defined]
        RunContext(
            environment=core.environment,
            triggered_by=core.triggered_by,
            base_url=core.base_url,
            app_filter=config.getoption("--app"),
            stream_filter=config.getoption("--stream"),
            case_filter=config.getoption("--case"),
        )
    )


def record_test_result(item: pytest.Item, report: pytest.TestReport) -> None:
    config = item.config
    if not getattr(config, "_qe_reporting_enabled", False):
        return

    recorded = getattr(config, "_qe_recorded_nodeids", set())
    fingerprint = f"{item.nodeid}::{report.when}"
    if fingerprint in recorded:
        return
    recorded.add(fingerprint)

    run_id = getattr(config, "_qe_run_id", None)
    if run_id is None:
        return

    marker = item.get_closest_marker("qe_meta")
    kwargs: dict[str, Any] = marker.kwargs if marker else {}
    browser_name = getattr(item, "_qe_browser_channel", "unknown")
    longrepr = str(report.longrepr) if report.failed else None

    _repository().record_result(
        TestResultRecord(
            run_id=run_id,
            case_id=kwargs.get("case_id"),
            app=kwargs.get("app"),
            node_id=item.nodeid,
            title=getattr(item, "originalname", item.name) or item.name,
            file_path=str(item.path),
            status=report.outcome,
            duration_ms=int(report.duration * 1000),
            error_message=longrepr,
            browser_name=browser_name,
        )
    )


def finish_run(config: pytest.Config, exitstatus: int) -> None:
    if not getattr(config, "_qe_reporting_enabled", False):
        return

    run_id = getattr(config, "_qe_run_id", None)
    if run_id is None:
        return

    _repository().complete_run(run_id, core.run_status(exitstatus))
