from __future__ import annotations

from common.base_page import BasePage
from common.google_search_box import GoogleSearchBox


class HomePage(BasePage):
    def __init__(self, page) -> None:
        super().__init__(page)
        self.search_box = GoogleSearchBox(page)

    def open_google(self) -> None:
        self.open("https://www.google.com/ncr")

    def is_ready(self) -> bool:
        return "Google" in self.title() and self.search_box.is_visible()
