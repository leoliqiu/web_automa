from __future__ import annotations

from apps.google_home.page_modules.home_page import HomePage
from qe_core import core

TEST_CASE = core.load_test_case("google-home", "GGL-HOME-001")
pytestmark = core.build_case_marks(TEST_CASE)


def test_google_home_page_is_ready(page) -> None:
    home_page = HomePage(page)
    home_page.open_google()
    assert home_page.is_ready()
