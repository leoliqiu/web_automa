from __future__ import annotations

from common.base_page import BasePage
from common.google_search_box import GoogleSearchBox


class SearchPage(BasePage):
    def __init__(self, page) -> None:
        super().__init__(page)
        self.search_box = GoogleSearchBox(page)

    def open_google(self) -> None:
        self.open("https://www.google.com/ncr")

    def search_for(self, query: str) -> None:
        self.search_box.fill(query)

    def current_query(self) -> str:
        return self.search_box.value()
