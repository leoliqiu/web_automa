from __future__ import annotations

from apps.google_search.page_modules.search_page import SearchPage
from qe_core import core

TEST_CASE = core.load_test_case("google-search", "GGL-SEARCH-001")
pytestmark = core.build_case_marks(TEST_CASE)


def test_google_search_box_accepts_query(page) -> None:
    search_page = SearchPage(page)
    search_page.open_google()
    search_page.search_for("Playwright Python")
    assert search_page.current_query() == "Playwright Python"
