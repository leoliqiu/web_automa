from __future__ import annotations

from playwright.sync_api import Page


class GoogleSearchBox:
    def __init__(self, page: Page) -> None:
        self.page = page
        self.selector = 'textarea[name="q"], input[name="q"]'

    def is_visible(self) -> bool:
        return self.page.locator(self.selector).first.is_visible()

    def fill(self, query: str) -> None:
        self.page.locator(self.selector).first.fill(query)

    def value(self) -> str:
        return self.page.locator(self.selector).first.input_value()
