from __future__ import annotations

from playwright.sync_api import Locator, Page


class BasePage:
    def __init__(self, page: Page) -> None:
        self.page = page

    def open(self, url: str) -> None:
        self.page.goto(url, wait_until="domcontentloaded")

    def title(self) -> str:
        return self.page.title()

    def locator(self, selector: str) -> Locator:
        return self.page.locator(selector).first
