"""Shared code for page modules and tests."""
