# QE Playwright Platform

Minimal Python Playwright framework for shared QE work.

## Structure

```text
src/
  apps/
    google_home/
      page_modules/
      testcases/
      tests/
    google_search/
      page_modules/
      testcases/
      tests/
  common/
  qe_core/
  qe_database/
  qe_reporting/
  qe_scripts/
```

## Design

- `page_modules/` holds project-specific page objects.
- `common/` holds reusable code shared across projects.
- `qe_core/core.py` contains `QeCore`, the dedicated class for framework features:
  - environment access
  - app and stream registry
  - test case discovery
  - browser validation
  - marker generation
  - app URL resolution
  - screenshot path creation

## Common code

Shared code belongs in `src/common/`.

Current examples:

- `[base_page.py](/C:/Users/LQ/PycharmProjects/qe-playwright-platform/src/common/base_page.py)`
- `[google_search_box.py](/C:/Users/LQ/PycharmProjects/qe-playwright-platform/src/common/google_search_box.py)`

Both Google projects reuse the shared search-box component.

## Run

Install dependencies:

```powershell
python -m pip install -e .
python -m playwright install chrome msedge
```

List cases:

```powershell
python -m qe_scripts.list_cases
```

Run all tests:

```powershell
python -m pytest
```

Run one project:

```powershell
python -m qe_scripts.run_tests --app google-home
```

Run one case:

```powershell
python -m qe_scripts.run_tests --case GGL-SEARCH-001
```

Run one browser:

```powershell
python -m qe_scripts.run_tests --app google-search --browser chrome
```

## Database

PostgreSQL support remains in place for:

- case catalog sync
- run storage
- result storage

Run migrations with:

```powershell
python -m qe_scripts.migrate_db
```
