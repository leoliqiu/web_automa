from __future__ import annotations

from pathlib import Path

import pytest
from playwright.sync_api import Browser, BrowserContext, Page, Playwright, sync_playwright
from playwright._impl._errors import TargetClosedError

from qe_core import core
from qe_reporting.plugin import (
    finish_run,
    initialize_reporting,
    record_test_result,
)


def pytest_addoption(parser: pytest.Parser) -> None:
    parser.addoption("--app", action="store", default=None, help="Run only one application key.")
    parser.addoption("--stream", action="store", default=None, help="Run only one stream key.")
    parser.addoption("--case", action="store", default=None, help="Run only one case id.")
    parser.addoption(
        "--browser",
        action="store",
        default=core.browsers_csv,
        help="Comma-separated browser channels. Supported values: chrome, msedge.",
    )
    parser.addoption(
        "--headed",
        action="store_true",
        default=False,
        help="Run browsers in headed mode.",
    )


def pytest_configure(config: pytest.Config) -> None:
    initialize_reporting(config)


def pytest_sessionfinish(session: pytest.Session, exitstatus: int) -> None:
    finish_run(session.config, exitstatus)


def pytest_generate_tests(metafunc: pytest.Metafunc) -> None:
    if "browser_channel" not in metafunc.fixturenames:
        return

    channels = core.browser_channels(metafunc.config.getoption("--browser"))
    metafunc.parametrize("browser_channel", channels, ids=channels, scope="session")


@pytest.hookimpl(hookwrapper=True)
def pytest_runtest_makereport(item: pytest.Item, call: pytest.CallInfo[object]) -> object:
    outcome = yield
    report = outcome.get_result()
    setattr(item, f"rep_{report.when}", report)

    if report.when == "call" or (report.when == "setup" and report.skipped):
        record_test_result(item, report)


@pytest.fixture(scope="session")
def playwright_instance() -> Playwright:
    with sync_playwright() as playwright:
        yield playwright


@pytest.fixture(scope="session")
def browser(playwright_instance: Playwright, browser_channel: str, request: pytest.FixtureRequest) -> Browser:
    headless = not request.config.getoption("--headed") and core.headless
    browser = playwright_instance.chromium.launch(channel=browser_channel, headless=headless)
    yield browser
    try:
        browser.close()
    except TargetClosedError:
        pass


@pytest.fixture(autouse=True)
def ensure_base_url(request: pytest.FixtureRequest) -> None:
    if "app_url" in request.fixturenames and not core.base_url:
        pytest.skip("Set BASE_URL in .env before running UI tests.")


@pytest.fixture()
def context(browser: Browser) -> BrowserContext:
    context = browser.new_context()
    yield context
    try:
        context.close()
    except TargetClosedError:
        pass


@pytest.fixture()
def page(context: BrowserContext, request: pytest.FixtureRequest, browser_channel: str) -> Page:
    current_page = context.new_page()
    request.node._qe_browser_channel = browser_channel  # type: ignore[attr-defined]
    request.node._qe_page = current_page  # type: ignore[attr-defined]
    yield current_page

    rep_call = getattr(request.node, "rep_call", None)
    if rep_call and rep_call.failed:
        current_page.screenshot(path=str(core.screenshot_path(request.node.name, browser_channel)), full_page=True)

    try:
        current_page.close()
    except TargetClosedError:
        pass


@pytest.fixture()
def app_key(request: pytest.FixtureRequest) -> str:
    marker = request.node.get_closest_marker("qe_meta")
    if marker is None:
        raise RuntimeError(f"Missing qe_meta marker on {request.node.nodeid}")
    return marker.kwargs["app"]


@pytest.fixture()
def app_definition(app_key: str):
    return core.get_application(app_key)


@pytest.fixture()
def app_url(app_definition) -> str:
    if not core.base_url:
        pytest.skip("Set BASE_URL in .env before running UI tests.")
    return core.app_url(app_definition.key)
